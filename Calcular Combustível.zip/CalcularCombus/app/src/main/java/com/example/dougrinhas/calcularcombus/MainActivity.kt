package com.example.dougrinhas.calcularcombus

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCalcular.setOnClickListener {

            val resultado = (num2.text.toString().toBigDecimal() * 0.7.toBigDecimal())

            if ( resultado > num1.text.toString().toBigDecimal()){
                result.text = "Maximo a ser pago: R$ "+resultado+" Abasteça com Alcool!"

            }else{
                result.text = "Maximo a ser pago: R$ "+resultado+" Abasteça com Gasolina! "
            }
        }

    }
}
