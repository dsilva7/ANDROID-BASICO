package com.example.dougrinhas.calcularimc

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        idadeBar.setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        idade.text = ("Idade: " + progress.toString())
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {
                       //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        idade.text = ("Idade: " + seekBar?.progress.toString())
                    }
                })
        pesoBar.setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        peso.text = ("Peso: "+progress.toString()+"kg")
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {
                       //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        peso.text = ("Peso: "+seekBar?.progress.toString()+"kg")
                    }
                })
        alturaBar.setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener{
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        altura.text = ("Altura: "+progress.toString()+"cm")
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {
                        //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        altura.text = ("Altura: "+seekBar?.progress.toString()+"cm")
                    }
                })

        lateinit var escolha:String

        //Radio group para escolher
        radioGroup?.setOnCheckedChangeListener { _, checkedId ->
            escolha = ""
            when(checkedId){
                R.id.radioButton1 -> escolha = "Pratique exercícios!"
                R.id.radioButton3 -> escolha = "Exercite-se mais!"
                R.id.radioButton2 -> escolha = "Continue com sua rotina de exercícios!"
            }
        }


        btnCalcular.setOnClickListener{
            var altura = alturaBar.progress.toDouble()
            var peso = pesoBar.progress.toDouble()
            var alturaReal =    altura/100

            var imc = peso / (alturaReal * alturaReal)


            if(imc <=18.49){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" , você está muito abaixo do peso ideal. \n$escolha"
                ratingSaude.rating = 3.toFloat()
            }
            if(imc > 18.49 && imc <= 24.99){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" ,seu peso está normal!. \n$escolha"
                ratingSaude.rating = 5.toFloat()
            }
            if(imc > 24.99 && imc <= 29.99){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" ,um pouco acima do peso ideal. \n$escolha"
                ratingSaude.rating = 4.toFloat()
            }
            if(imc > 29.99 && imc <= 34.99){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" ,acima do peso, inicie uma dieta. \n$escolha"
                ratingSaude.rating = 2.toFloat()
            }
            if(imc > 34.99 && imc <= 39.99){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" ,inicie uma dieta rigorosa. \n$escolha"
                ratingSaude.rating = 1.toFloat()
            }
            if(imc >= 40.00){
                result.text = "Seu IMC é de: "+String.format("%.2f",imc)+" ,procure acompanhamento médico. \n$escolha"
                ratingSaude.rating = 0.toFloat()
            }
        }

        txtSexo.text = "Homem"
        switchSexo?.setOnClickListener{
            if(switchSexo.isChecked){
                txtSexo.text = "Mulher"
            }
            else{
                txtSexo.text = "Homem"
            }
        }

    }
}
