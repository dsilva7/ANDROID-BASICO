package com.example.dougrinhas.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_seguro_desemprego.*

class SeguroDesempregoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seguro_desemprego)

        //incluir botão para retornar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        btnCalcSeg.setOnClickListener {

            var valorRecebido: Double = 0.0

            val mediaSal = ((antepenultimoSalario.text.toString().toDouble() +
                    penultimoSalario.text.toString().toDouble() +
                    ultimoSalario.text.toString().toDouble())) / 3

            if (mediaSal <= 1222.77){
                valorRecebido = mediaSal * 0.8
            }
            if (mediaSal > 1222.77 && mediaSal <= 2038.15){
                valorRecebido = (mediaSal * 0.5) + 978.22
            }
            if(mediaSal > 2038.15){
                valorRecebido = 1385.91
            }

            var numParcelas: Int = 0
            val mesesTrabalhados = numMesesTrabalhados.text.toString().toInt()

            if(mesesTrabalhados > 3 && mesesTrabalhados < 11){
                numParcelas = 3
            }
            if (mesesTrabalhados > 12 && mesesTrabalhados < 23){
                numParcelas = 4
            }
            if(mesesTrabalhados >= 24){
                numParcelas = 5
            }

            txtResultado.text = "Total a receber: $valorRecebido\n"+
                    "Nº de Parcelas: $numParcelas"
        }

        btnAcessFonte.setOnClickListener {
            val uris = Uri.parse("https://www.pontorh.com.br/como-calcular-seguro-desemprego/")
            val intents = Intent(Intent.ACTION_VIEW,uris)
            startActivity(intents)
        }

    }
}