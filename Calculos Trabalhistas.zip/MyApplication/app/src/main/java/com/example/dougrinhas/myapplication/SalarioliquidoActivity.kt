package com.example.dougrinhas.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter

import kotlinx.android.synthetic.main.activity_salario_liquido.*

class SalarioliquidoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_salario_liquido)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        var mesEscolhido = ""
        var meses = arrayOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho","Julho",
                "Agosto", "Setembro", "Outubro", "Novembro","Dezembro")

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,meses)

        spinnerMeses.adapter = adapter

        spinnerMeses.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long){
                when(position){
                    0 -> {
                        mesEscolhido = "Janeiro"
                    }
                    1-> {
                        mesEscolhido = "Fevereiro"
                    }
                    2->{
                        mesEscolhido = "Março"
                    }
                    3->{
                        mesEscolhido = "Abril"
                    }
                    4->{
                        mesEscolhido = "Maio"
                    }
                    5->{
                        mesEscolhido = "Junho"
                    }
                    6->{
                        mesEscolhido = "Julho"
                    }
                    7->{
                        mesEscolhido = "Agosto"
                    }
                    8->{
                        mesEscolhido = "Setembro"
                    }
                    9->{
                        mesEscolhido = "Outubro"
                    }
                    10->{
                        mesEscolhido = "Novembro"
                    }
                    11->{
                        mesEscolhido = "Dezembro"
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
                mesEscolhido = ""
            }
        }
        btnCalcularSalLiq.setOnClickListener {

            //Valor do desconto do INSS
            var Inss: Double = 0.0
            var Ir :Double = 0.0

            var salarioBruto = vlrSalarioBruto.text.toString().toDouble()

            //Separar alíquota referente ao salário bruto
            if (salarioBruto <= 1693.72){
                Inss = salarioBruto * 0.08
            }
            if (salarioBruto >=1693.73 && salarioBruto <= 2822.90){
                Inss = salarioBruto * 0.09
            }
            if (salarioBruto >=2822.91 && salarioBruto <= 5645.80){
                Inss = salarioBruto * 0.11
            }
            if (salarioBruto > 5645.80){
                Inss = 621.04
            }

            //Separar desconto do IR
            if (salarioBruto >= 1903.99 && salarioBruto <= 2826.65){
                Ir = 142.80
            }
            if(salarioBruto >= 2826.66 && salarioBruto <= 3751.05){
                Ir = 354.80
            }
            if(salarioBruto >= 3751.06 && salarioBruto <= 4664.68){
                Ir = 636.13
            }
            if (salarioBruto >= 4664.68){
                Ir = 869.36
            }


            //Descobrir o total de desconto das faltas no mês
            val vlrDescontoFaltas = (salarioBruto / 20) * numFaltas.text.toString().toInt()

            //Calcular salario liquido
            val salarioLiquidoAReceber = (salarioBruto - Inss - Ir - vlrDescontoFaltas) + vlrComissao.text.toString().toDouble()

            val comissao = vlrComissao.text.toString().toDouble()

            txtResultadoSalLiq.text = "Mês: $mesEscolhido\n"+
                    "Salário Bruto: $salarioBruto\n" +
                    "INSS: $Inss\n" +
                    "Imposto de Renda: $Ir\n" +
                    "Desconto de Faltas: $vlrDescontoFaltas\n" +
                    "Comissões: $comissao\n"+
                    "Total a Receber: $salarioLiquidoAReceber"
        }

        btnFonteSalLiq.setOnClickListener {
            val uris = Uri.parse("https://calculosalarioliquido.com")
            val intents = Intent(Intent.ACTION_VIEW,uris)
            startActivity(intents)
        }
    }
}