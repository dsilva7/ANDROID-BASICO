package com.example.dougrinhas.projetofilme.view

import android.app.Activity
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.example.dougrinhas.projetofilme.R
import com.example.dougrinhas.projetofilme.adapter.FilmeRecyclerAdapter
import com.example.dougrinhas.projetofilme.db.Filme
import com.example.dougrinhas.projetofilme.viewModel.FilmeViewModel
import kotlinx.android.synthetic.main.activity_lista_filme.*
import java.lang.Exception
import java.util.Observer

class ActivityListaFilme : AppCompatActivity() {

    private lateinit var filmeViewModel: FilmeViewModel

    private val requestCodeFilme = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_filme)

        val recyclerView = rvListaFilme
        val adapter = FilmeRecyclerAdapter(this)
        recyclerView.adapter = adapter
        //Click lista " ao clicar na lista, acessa o itemclick, que abrira uma nova activty passando o objeto
        // quando o activty for fechado"
        adapter.onItemClick = {filme ->
            val intent = Intent(this@ActivityListaFilme, ActivityNovoFilme::class.java)
            intent.putExtra(ActivityNovoFilme.EXTRA_REPLY, filme)
            startActivityForResult(intent, requestCodeFilme)
        }
        //fim click lista
        recyclerView.layoutManager = LinearLayoutManager(this)

        filmeViewModel =
                ViewModelProviders.of(this).
                        get(FilmeViewModel::class.java)

        filmeViewModel.allFilmes.observe(this, android.arch.lifecycle.Observer
        { filmes->filmes?.let { adapter.setFilmeList(it) } })

        fbAddFilme?.setOnClickListener{
            val intent = Intent(this@ActivityListaFilme, ActivityNovoFilme::class.java)
            startActivityForResult(intent, requestCodeFilme)

        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeFilme && resultCode == Activity.RESULT_OK){
            data.let {
                try {
                    //caso exista o objeto recebido, adicione em um objeto em filme. Pegar um dado serializado
                    //feito cast de filme para dizer que ele de fato é objeto que pretendo receber
                    val filme: Filme = data?.getSerializableExtra(ActivityNovoFilme.EXTRA_REPLY) as Filme
                    //se tiver id > 0 sera editado se nao ira inserir
                    if (filme.id> 0) filmeViewModel.update(filme)
                    else filmeViewModel.insert(filme)
                }catch (e: Exception){
                    val filme: Filme = data?.getSerializableExtra(ActivityNovoFilme.EXTRA_DELETE) as Filme
                    filmeViewModel.delete(filme)
                }

            }

        }
        else {
            Toast.makeText(applicationContext,"ERROR NOT FOUND 404", Toast.LENGTH_LONG).show()
        }
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return super.onOptionsItemSelected(item)
    }
}