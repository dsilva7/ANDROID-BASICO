package com.example.dougrinhas.projetofilme.repository

import android.arch.lifecycle.LiveData
import com.example.dougrinhas.projetofilme.db.Filme
import com.example.dougrinhas.projetofilme.db.FilmeDAO

class FilmeRepository(private val filmeDAO: FilmeDAO) {

    val allFilme : LiveData<List<Filme>> = filmeDAO.getAll()

    fun insert (filme : Filme){
        filmeDAO.insert(filme)
    }

    fun update (filme : Filme){
        filmeDAO.update(filme)
    }

    fun delete(filme: Filme){
        filmeDAO.delete(filme)
    }
}