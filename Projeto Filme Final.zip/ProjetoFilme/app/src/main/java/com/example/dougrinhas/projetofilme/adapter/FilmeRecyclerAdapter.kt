package com.example.dougrinhas.projetofilme.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.dougrinhas.projetofilme.R
import com.example.dougrinhas.projetofilme.db.Filme
import kotlinx.android.synthetic.main.item_lista_filme.view.*

class FilmeRecyclerAdapter internal constructor(context: Context) :
        RecyclerView.Adapter<FilmeRecyclerAdapter.ViewHolder>() {

    //Criar para fazer método de selecionar cada item na lista
    var onItemClick: ((Filme) -> Unit)? = null
    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var filme = emptyList<Filme>() // cachear os elementos



    override fun onCreateViewHolder(holder: ViewGroup, position: Int): ViewHolder {
        //inflar para aparecer os itens na lista
        val view = inflater.inflate(R.layout.item_lista_filme, holder,
                false )
        return ViewHolder(view)
    }

    //tamanho da lista
    override fun getItemCount() = filme.size

    //itens a serem exibidos na lista pegando valores
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val current = filme[position]
        holder.nomeFilme.text = current.nome
        holder.anoFilm.text = current.anoLanc
        holder.classFilm.text = current.classificacao
        holder.duraFilm.text = current.duracao


    }

    //itens da lista
    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val nomeFilme: TextView = itemView.txtFilmeListName
        val anoFilm: TextView = itemView.txtAno
        val duraFilm: TextView = itemView.txtDura
        val classFilm: TextView = itemView.txtClass

        init {

            itemView.setOnClickListener{
                onItemClick?.invoke(filme[adapterPosition])
            }
        }
    }


    fun setFilmeList(filmeList: List<Filme>){
        this.filme = filmeList
        notifyDataSetChanged()
    }
}