package com.example.dougrinhas.projetofilme.db

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.media.Image
import android.widget.Spinner
import java.io.Serializable
import java.util.*

@Entity(tableName = "filme_table")
class Filme (

    @ColumnInfo(name = "nome")
    var nome: String,
    @ColumnInfo(name = "sinopse")
    var sinopse: String = "",
    @ColumnInfo(name = "ano")
    var anoLanc: String,
    @ColumnInfo(name = "direção")
    var direcao: String,
    @ColumnInfo(name = "elenco")
    var elenco: String = "",
    @ColumnInfo(name = "classificacao")
    var classificacao: String,
    @ColumnInfo(name = "duracao")
    var duracao: String
    ):Serializable{
        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "id")
        var id: Long = 0
}