package com.example.dougrinhas.projetofilme.view

import android.Manifest
import android.app.*
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.dougrinhas.projetofilme.R
import com.example.dougrinhas.projetofilme.db.Filme
import kotlinx.android.synthetic.main.activity_filme.*
import kotlinx.android.synthetic.main.item_lista_filme.*
import java.lang.Exception

class ActivityNovoFilme : AppCompatActivity() {

    private var image_uri: Uri? = null
    private var mCurrentPhotoPath: String = ""

    lateinit var filme: Filme

    //canal para trabalhar com a notificações
    private val channelId = "com.example.dougrinhas.projetofilme"

    private var notificationManager: NotificationManager? = null


    companion object {

        private val REQUEST_IMAGE_GARELLY = 1000
        private val REQUEST_IMAGE_CAPTURE = 2000
        const val EXTRA_REPLY = "view.REPLY"
        const val EXTRA_DELETE = "view.Delete"

    }

    //Ininciando clico de vida activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filme)

        notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE)
                          as NotificationManager

        // botão de voltar ativo no menu superior esquerdo
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        fAddFilme?.setOnClickListener {
            fAddFilme.setOnCreateContextMenuListener { menu, v, menuInfo ->
                menu.add(Menu.NONE, 1, Menu.NONE, "Escolher foto")


            }
        }

        val intent: Intent = getIntent()
        try {
            //recebe o objeto da intent
            filme = intent.getSerializableExtra(EXTRA_REPLY) as Filme

            //Atribuindo valor para os itens do formulário
            filme.let {
                etNome.setText(filme.nome)
                etSinopse.setText(filme.sinopse)
                anoLanc.setText(filme.anoLanc)
                elenco.setText(filme.elenco)
                dire.setText(filme.direcao)
                classificacao.setText(filme.classificacao)
                duracao.setText(filme.duracao)
            }

        }catch (e: Exception){
        }
    }

    //pegando imagem da galeria
    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_IMAGE_GARELLY)

    }

    private fun takePicture() {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "Nova Imagem")
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg")

        image_uri = contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        if(intent.resolveActivity(packageManager) != null) {
            mCurrentPhotoPath = image_uri.toString()
            intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }

        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
    }

    //permissão para pegar imagem da galeria
    private fun getPermissionImageFromGallery(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_DENIED) {
                // permissão negada
                val permission = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                requestPermissions(permission, REQUEST_IMAGE_GARELLY)
            } else {
                // permissão aceita
                pickImageFromGallery()
            }
        }
        else{

            pickImageFromGallery()
        }
    }

    //permissão para pegar imagem da camera
   /* private fun getPermissionTakePicture(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_DENIED ||
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_DENIED) {
                // permissão negada
                val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                requestPermissions(permission, REQUEST_IMAGE_CAPTURE)
            } else {
                // permissão aceita
                takePicture()
            }
        }
        else{

        }
    }*/



    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when(requestCode){
            REQUEST_IMAGE_GARELLY -> {
                if(grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) pickImageFromGallery()
                else Toast.makeText(this, "Permissão negada", Toast.LENGTH_SHORT).show()
            }
            REQUEST_IMAGE_CAPTURE ->{
                if(grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) takePicture()
                else Toast.makeText(this, "Permissão negada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_IMAGE_GARELLY) imgNewFilme.setImageURI(data?.data)

        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_IMAGE_CAPTURE) imgNewFilme.setImageURI(image_uri)

    }

    override fun onContextItemSelected(item: MenuItem?): Boolean {
        when(item!!.itemId){
            1 -> getPermissionImageFromGallery()

        }
        return super.onContextItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_novo_filme, menu)
        try {
            filme.let {
                //tornar o botao delete visivel
                val menuItem = menu?.findItem(R.id.menu_filme_delete)
                menuItem?.isVisible = true }

        }catch (e: Exception){
            //tornar o botao delete invisivel
            val menuItem = menu?.findItem(R.id.menu_filme_delete)
            menuItem?.isVisible = false

        }
        return true
    }

    //verificando se ja existe, caso exista ele ira para edição se não
    //ira criar um novo
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return if (item?.itemId == android.R.id.home) {
            finish()
            true
        }
        else if (item?.itemId == R.id.menu_filme_save) {
            if (etNome.text.isNullOrEmpty())Toast.makeText(this, "Insira o nome do filme",
                    Toast.LENGTH_LONG).show()
            else {
                if ((::filme.isInitialized)&&(filme.id > 0)) {
                    filme.sinopse = etSinopse.text.toString()
                    filme.direcao = dire.text.toString()
                    filme.anoLanc = anoLanc.text.toString()
                    filme.elenco = elenco.text.toString()
                    filme.classificacao = classificacao.text.toString()
                    filme.duracao = duracao.text.toString()

                    //adicionando notificação
                    notificacao(descricao = "EDITADO COM SUCESSO!")

                } else {
                    filme = Filme(

                            nome = etNome.text.toString(),
                            sinopse = etSinopse.text.toString(),
                            anoLanc = anoLanc.text.toString(),
                            elenco = elenco.text.toString(),
                            direcao = dire.text.toString(),
                            classificacao = classificacao.text.toString(),
                            duracao = duracao.text.toString()

                    )
                    //Adicionando notificação
                    notificacao(descricao = "CRIADO COM SUCESSO!")
                }
                //criando uma intent para inserir os dados de resposta
                val replyIntent = Intent ()
                //inserindo na intent a chave (EXTRA_REPLY) e o valor (filme)
                replyIntent.putExtra(EXTRA_REPLY, filme)
                //enviando os dados
                setResult(Activity.RESULT_OK, replyIntent)
            }
            finish()
            true
        }
        else if (item?.itemId == R.id.menu_filme_delete){
            val replyIntent = Intent()
            replyIntent.putExtra(EXTRA_DELETE, filme)
            setResult(Activity.RESULT_OK, replyIntent)
            true

        }
        else{
            super.onOptionsItemSelected(item)


        }

    }



    fun notificacao(descricao: String){
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val mNotification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            Notification.Builder(this, channelId)
        } else {
            Notification.Builder(this)
        }.apply {
            setContentIntent(pendingIntent)
            // adicionando um ícone na notificação
            setSmallIcon(R.drawable.notification_icon_background)
            setAutoCancel(true)
            // título da notificação
            setContentTitle(filme.nome)
            //passando 'descricao' como parametro para modificar o texto da notificação
            setContentText(descricao)


        }.build()
        val mNotificationId: Int = 1000
        val nManager = this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nManager.notify(mNotificationId, mNotification)
        }




    }




