package com.example.dougrinhas.filmes

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val channelId= "com.example.dougrinhas.filmes"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var historias = arrayOf ("Um sonho possível", "Tudo por um sonho", "+ Velozes e + Furiosos")

        val adapter = ArrayAdapter ( this, android.R.layout.simple_dropdown_item_1line, historias)

        sHistoria.adapter = adapter

        sHistoria.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {


                val selectedItem = parent.getItemAtPosition(position).toString()

                when (position) {
                    0 -> {
                        txtResumo.text = (selectedItem + "\nMichael Oher, um adolescente afrodescendente sem teto," +
                                " entrava e saía do sistema de ensino ano a ano. Uma noite de chuva, Leigh Anne Tuohy e seu marido" +
                                " levam-no para sua casa. A família eventualmente torna-se representante legal de Michael, transformando" +
                                " tanto a sua vida quanto a deles. O tamanho de Michael e seu instinto protetor fazem dele uma estrela" +
                                " no campo de futebol e, com a ajuda de sua nova família e de uma tutora dedicada, ele percebe seu " +
                                "potencial como estudante e jogador de futebol.")

                        imgHistoria.visibility = View.VISIBLE

                        imgHistoria.setImageResource(R.drawable.sonho)

                        notificacao()
                    }
                    1 -> {
                        txtResumo.text = (selectedItem + "\nAos oito anos de idade, Jay Moriarty quase morreu afogado." +
                                " O menino foi salvo por um vizinho que acabou se tornando seu mentor no surfe. Aos 16 anos, " +
                                "Jay conhece as mitológicas ondas gigantes de Mavericks e " +
                                "treina pesado para poder enfrentá-las.")
                        imgHistoria.visibility = View.VISIBLE
                        imgHistoria.setImageResource(R.drawable.onda)
                        notificacao()
                    }

                    2 -> {
                        txtResumo.text = (selectedItem + "\nO ex-policial Brian O'Conner se muda de Los Angeles para Miami para recomeçar sua vida." +
                                "Ele acaba se envolvendo em rachas na sua nova cidade com seu amigo Tej e Suki. " +
                                "Suas aventuras terminam quando ele é preso e faz um acordo com agentes do FBI. " +
                                "Brian tem a missão muito perigosa de prender um poderoso chefe do cartel das drogas..")
                        imgHistoria.visibility = View.VISIBLE
                        imgHistoria.setImageResource(R.drawable.velozes
                        )
                        notificacao()
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {
                imgHistoria.visibility = View.GONE
                txtResumo.text = ""
            }
        }


    }

    fun notificacao(){
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val mNotification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            Notification.Builder(this)
        }.apply {
            setContentIntent(pendingIntent)
            // adicionando um ícone na notificação
            setSmallIcon(R.drawable.notification_icon_background)
            setAutoCancel(true)
            // título da notificação
            setContentTitle(sHistoria.selectedItem.toString())
            // mensagem da notificação
            setContentText("Toque para ver sinopse")
        }.build()
        val mNotificationId: Int = 1000
        val nManager = this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nManager.notify(mNotificationId, mNotification)
    }
}
